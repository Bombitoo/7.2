#include <stdio.h>


void sum() 
{
 int q,w;
 printf("q=")
 scanf("%d",&q);
 
 printf("w=")
 scanf("%d",&w);
 
 printf("%d",q+w)
}

int main()
{
 sum();  
 
 return 1;    
}
